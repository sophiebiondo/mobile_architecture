package com.example.cs360finalprojectv2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Database Info
    public static final String DATABASE_NAME = "UserData.db";
    // Increment the database version to trigger onUpgrade for existing users.
    public static final int DATABASE_VERSION = 2;

    // Table Names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_ITEMS = "items";

    // Users Table Columns
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Items Table Columns
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    // *** CHANGED *** Add a new column constant for the item count.
    public static final String COLUMN_ITEM_COUNT = "item_count";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /** Called when the database is created for the first time. */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS = "CREATE TABLE " + TABLE_USERS +
                "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS);

        // *** CHANGED *** Update the table creation SQL to include the new column.
        String CREATE_ITEMS = "CREATE TABLE " + TABLE_ITEMS +
                "(" + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT, " +
                COLUMN_ITEM_COUNT + " INTEGER)"; // Added the new integer column
        db.execSQL(CREATE_ITEMS);
    }

    /** Called when the database needs to be upgraded. This will now be triggered
     *  because DATABASE_VERSION was changed from 1 to 2. */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This simple approach drops and recreates the tables.
        // For a real-world app, you might use ALTER TABLE to preserve data.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    /** User CRUD methods */
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    /** Item CRUD */
    // Update method signature and logic to include item count.
    public boolean insertItem(String itemName, int itemCount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ITEM_NAME, itemName);
        cv.put(COLUMN_ITEM_COUNT, itemCount); // Add the count to the content values
        long result = db.insert(TABLE_ITEMS, null, cv);
        return result != -1;
    }

    // Update method signature and logic to include new item count.
    public boolean updateItem(int id, String newName, int newCount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ITEM_NAME, newName);
        cv.put(COLUMN_ITEM_COUNT, newCount); // Add the count to the content values
        int affected = db.update(TABLE_ITEMS, cv, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        return affected > 0;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int affected = db.delete(TABLE_ITEMS, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        return affected > 0;
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        // The existing query "SELECT *" works perfectly as it will now automatically include the new column.
        return db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);
    }
}
