package com.example.cs360finalprojectv2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public class ItemAdapter extends ArrayAdapter<Item> {

    private final Context context;
    private final List<Item> items;

    public ItemAdapter(@NonNull Context context, @NonNull List<Item> items) {
        super(context, R.layout.item_data, items);
        this.context = context;
        this.items = items;
    }

    // ViewHolder class to cache view references for performance
    private static class ViewHolder {
        TextView itemName;
        TextView itemId;
        TextView itemCount;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            // If the view is new, inflate it and create a ViewHolder
            convertView = LayoutInflater.from(context).inflate(R.layout.item_data, parent, false);
            holder = new ViewHolder();
            holder.itemName = convertView.findViewById(R.id.item_name);
            holder.itemId = convertView.findViewById(R.id.item_id);
            holder.itemCount = convertView.findViewById(R.id.item_count);
            convertView.setTag(holder);
        } else {
            // If the view is being recycled, retrieve the existing ViewHolder
            holder = (ViewHolder) convertView.getTag();
        }

        // Get the data item for the current position
        Item currentItem = items.get(position);


        // Set the data into the views using the correct getter methods

        // Set the item name
        holder.itemName.setText(currentItem.getItemName());

        // Use getItemId() to set the ID's text
        holder.itemId.setText("ID: " + currentItem.getItemId());

        // Use getItemCount() to set the count's text
        holder.itemCount.setText("Count: " + String.valueOf(currentItem.getItemCount()));

        return convertView;
    }
}
