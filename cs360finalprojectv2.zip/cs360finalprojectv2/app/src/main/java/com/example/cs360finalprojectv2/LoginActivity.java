package com.example.cs360finalprojectv2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private Button registerButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);

        // Find all the views by their IDs
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);
        registerButton = findViewById(R.id.register_button);

        // --- SET ONCLICK LISTENERS ---

        // 1. Handle Login
        loginButton.setOnClickListener(v -> handleLogin());

        // 2. Handle showing the registration UI
        createAccountButton.setOnClickListener(v -> showRegistrationUI());

        // 3. Handle the actual registration logic
        registerButton.setOnClickListener(v -> handleRegistration());
    }

    // Exception handling for login
    private void handleLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate user with the database
        if (dbHelper.validateUser(username, password)) {
            // If login is successful, show a message and navigate to MainActivity
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            // Finish LoginActivity so the user cannot go back to it
            finish();
        } else {
            // If login fails, show an error message
            Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_LONG).show();
        }
    }

    private void showRegistrationUI() {
        // When user clicks "Create Account", hide the login buttons and show the register button
        loginButton.setVisibility(View.GONE);
        createAccountButton.setVisibility(View.GONE);
        registerButton.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Enter a new username and password, then click Register.", Toast.LENGTH_LONG).show();
    }

    // Exception handling for registration
    private void handleRegistration() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to insert the new user into the database
        if (dbHelper.insertUser(username, password)) {
            Toast.makeText(this, "Account created successfully! Please log in.", Toast.LENGTH_LONG).show();
            // Reset the UI back to the login state
            resetToLoginUI();
        } else {
            Toast.makeText(this, "Registration failed. User may already exist.", Toast.LENGTH_LONG).show();
        }
    }

    private void resetToLoginUI() {
        // Clear the input fields
        usernameEditText.setText("");
        passwordEditText.setText("");
        // Show the login buttons and hide the register button
        loginButton.setVisibility(View.VISIBLE);
        createAccountButton.setVisibility(View.VISIBLE);
        registerButton.setVisibility(View.GONE);
    }
}
