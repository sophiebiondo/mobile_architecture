package com.example.cs360finalprojectv2;


import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

/**
 * Handles sign up and user insertion into SQLite database.
 */
public class SignupActivity extends Activity {

    private EditText usernameET, passwordET;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        usernameET = findViewById(R.id.editTextUsername);
        passwordET = findViewById(R.id.editTextPassword);
        dbHelper = new DatabaseHelper(this);
    }

    /** OnClick handler for signup button.*/
    public void signup(View view) {
        String username = usernameET.getText().toString();
        String password = passwordET.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dbHelper.insertUser(username, password)) {
            Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error Creating Account", Toast.LENGTH_SHORT).show();
        }
    }
}