package com.example.cs360finalprojectv2;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

/**
 * SplashActivity
 * ---------------
 * This activity is the entry point of the app.
 * It displays a splash screen for a few seconds,
 * then redirects the user to LoginActivity.
 */
public class SplashActivity extends AppCompatActivity {

    // Duration of splash screen in milliseconds
    private static final int SPLASH_DURATION = 3000; // 3 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Delay and then launch LoginActivity
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // close SplashActivity so user can't return to it
        }, SPLASH_DURATION);
    }
}
