package com.example.cs360finalprojectv2;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

/**
 * Activity to send SMS messages, manages permissions.
 */
public class SMSActivity extends Activity {

    private EditText phoneET, messageET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        phoneET = findViewById(R.id.editTextPhone);
        messageET = findViewById(R.id.editTextMessage);

        PermissionHelper.checkSMSPermission(this);
    }

    /** OnClick handler for "Send SMS" button. */
    public void sendSMS(View view) {
        String phone = phoneET.getText().toString();
        String message = messageET.getText().toString();

        if (!PermissionHelper.checkSMSPermission(this)) {
            Toast.makeText(this, "SMS Permission Required", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}