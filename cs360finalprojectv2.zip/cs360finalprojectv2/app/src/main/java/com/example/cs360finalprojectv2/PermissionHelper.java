package com.example.cs360finalprojectv2;


import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;

public class PermissionHelper {
    public static final int SMS_PERMISSION_CODE = 100;

    public static boolean checkSMSPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (activity.checkSelfPermission(android.Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(
                        new String[]{android.Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE
                );
                return false;
            }
        }
        return true;
    }

    public static void handlePermissionResult(int requestCode, int[] grantResults, Activity activity) {
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed
            } else {
                // Permission denied, inform user
            }
        }
    }
}