package com.example.cs360finalprojectv2;


/**
 * Represents a single data item displayed in the grid view.
 */
public class Item {
    private String itemId;
    private String itemName;
    private int itemCount; // Added field for the item count

    // Constructor updated to include the item count
    public Item(String itemId, String itemName, int itemCount) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemCount = itemCount;
    }

    // Getter for the item ID
    public String getItemId() {
        return itemId;
    }

    // Getter for the item name
    public String getItemName() {
        return itemName;
    }

    // Getter for the new item count
    public int getItemCount() {
        return itemCount;
    }

    // Setter for the item count (for later updates)
    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }
}
