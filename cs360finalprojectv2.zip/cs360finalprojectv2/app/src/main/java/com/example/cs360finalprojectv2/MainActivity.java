package com.example.cs360finalprojectv2;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

/**
 * Main activity: displays items, allows CRUD operations via data grid.
 * Also handles SMS permission request via a button.
 */
public class MainActivity extends Activity {

    private static final int SMS_PERMISSION_CODE = 100;

    private GridView gridView;
    private ItemAdapter adapter;
    private DatabaseHelper dbHelper;
    private EditText inputName, inputId, inputCount;
    private Button btnRequestSms;

    // *** CHANGED: This method now returns ArrayList<Item> instead of ArrayList<DataModel> ***
    private ArrayList<Item> loadAllItems() {
        ArrayList<Item> items = new ArrayList<>();
        Cursor cursor = dbHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                // Create new Item object and add to the list
                items.add(new Item(

                        String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID))),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_COUNT))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    // Recall saved instances of items
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.data_grid);
        inputName = findViewById(R.id.input_name);
        inputId = findViewById(R.id.input_id);
        inputCount = findViewById(R.id.input_count);

        dbHelper = new DatabaseHelper(this);

        btnRequestSms = findViewById(R.id.btn_request_sms);

        // Check if permission already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            btnRequestSms.setVisibility(View.GONE); // hide button if already granted
        } else {
            btnRequestSms.setVisibility(View.VISIBLE);
            btnRequestSms.setOnClickListener(v -> requestSmsPermission());
        }

        refreshGrid();
    }

    private void refreshGrid() {
        // Now this line is correct, as loadAllItems() returns the expected type for ItemAdapter.
        adapter = new ItemAdapter(this, loadAllItems());
        gridView.setAdapter(adapter);
    }

    /** Adds a new item to the grid/database */
    public void addItem(View view) {
        String name = inputName.getText().toString().trim();
        String countStr = inputCount.getText().toString().trim();

        if (name.isEmpty() || countStr.isEmpty()) {
            Toast.makeText(this, "Name and count are required", Toast.LENGTH_SHORT).show();
            return;
        }
        int count = Integer.parseInt(countStr);

        if (dbHelper.insertItem(name, count)) {
            Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
            inputName.setText("");
            inputCount.setText("");
            refreshGrid();

            // Check inventory level for the newly added item.
            checkAndNotifyLowInventory(name, count);

        } else {
            Toast.makeText(this, "Failed to add item.", Toast.LENGTH_SHORT).show();
        }
    }


    /**
     * Checks if an item's inventory is low and sends an SMS notification if it is.
     * @param itemName The name of the item to notify about.
     * @param count The current count of the item.
     */
    private void checkAndNotifyLowInventory(String itemName, int count) {
        // Define the threshold for low inventory.
        final int LOW_INVENTORY_THRESHOLD = 10;

        if (count < LOW_INVENTORY_THRESHOLD) {
            // First, check if we have permission to send SMS.
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                try {
                    // TODO: Replace with a real phone number.
                    String phoneNumber = "5554";
                    String message = "Low inventory alert: Item '" + itemName + "' has only " + count + " left.";

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                    // Show a confirmation Toast on the UI thread.
                    Toast.makeText(this, "Low inventory SMS sent for " + itemName, Toast.LENGTH_LONG).show();

                } catch (Exception e) {
                    Toast.makeText(this, "Failed to send low inventory SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                // If permission is not granted, inform the user.
                Toast.makeText(this, "SMS permission not granted. Cannot send inventory alert.", Toast.LENGTH_LONG).show();
                // Make the 'Enable SMS' button visible so the user can grant permission.
                if (btnRequestSms.getVisibility() == View.GONE) {
                    btnRequestSms.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    /** Updates an existing item in the database/grid */
    public void updateItem(View view) {
        String idStr = inputId.getText().toString();
        String newName = inputName.getText().toString();
        String newCountStr = inputCount.getText().toString();

        if (idStr.isEmpty()) {
            Toast.makeText(this, "ID Required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (newName.isEmpty() || newCountStr.isEmpty()) {
            Toast.makeText(this, "Name and count are required to update", Toast.LENGTH_SHORT).show();
            return;
        }

        int id = Integer.parseInt(idStr);
        int newCount = Integer.parseInt(newCountStr);
        if (dbHelper.updateItem(id, newName, newCount)) {
            Toast.makeText(this, "Item Updated to " + newCount, Toast.LENGTH_SHORT).show();
            // Clear input fields after a successful update
            inputId.setText("");
            inputName.setText("");
            inputCount.setText("");
            refreshGrid();
        }
    }

    /** Deletes an item given an ID */
    public void deleteItem(View view) {
        String idStr = inputId.getText().toString();
        if (idStr.isEmpty()) {
            Toast.makeText(this, "ID Required", Toast.LENGTH_SHORT).show();
            return;
        }
        int id = Integer.parseInt(idStr);
        if (dbHelper.deleteItem(id)) {
            Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
            // Clear input ID field after successful deletion
            inputId.setText("");
            refreshGrid();
        }
    }

    private void notifyLowInventory(String itemName, int count) {
        // Check for permission before sending SMS
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                String phoneNumber = "5554"; // Use a real number or emulator number
                String message = "Low inventory alert: Item '" + itemName + "' has only " + count + " left.";

                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                Toast.makeText(this, "Low inventory SMS sent for " + itemName, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            // Optionally inform the user that SMS can't be sent without permission
            Toast.makeText(this, "SMS permission not granted. Cannot send inventory alert.", Toast.LENGTH_LONG).show();
            // TODO: Consider re-request permission or guide the user to settings
            if (btnRequestSms.getVisibility() == View.GONE) {
                btnRequestSms.setVisibility(View.VISIBLE);
            }
        }
    }

    /** Request SMS permission */
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    /** Handle permission result */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
                btnRequestSms.setVisibility(View.GONE);

                // Send a test SMS immediately after permission granted
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    // Emulator phone numbers: 5554, 5556, etc.
                    smsManager.sendTextMessage("5554", null,
                            "Test notification: SMS alerts enabled!",
                            null, null);
                    Toast.makeText(this, "Test SMS sent to 5554", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }

            } else {
                Toast.makeText(this, "SMS permission denied. App will continue without SMS.", Toast.LENGTH_LONG).show();
                btnRequestSms.setVisibility(View.VISIBLE);
            }
        }


    }
}
